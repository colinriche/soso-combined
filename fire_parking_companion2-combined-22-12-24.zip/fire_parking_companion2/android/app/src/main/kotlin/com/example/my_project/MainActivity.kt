package com.mainstream.fireparkingcompanion2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
